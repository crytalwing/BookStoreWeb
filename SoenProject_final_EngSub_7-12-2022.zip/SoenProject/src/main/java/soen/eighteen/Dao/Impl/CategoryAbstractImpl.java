package soen.eighteen.Dao.Impl;


import soen.eighteen.Dao.AbstractDao;
import soen.eighteen.Entity.Category;

public class CategoryAbstractImpl extends AbstractDao<Category> {
	public CategoryAbstractImpl()
	{
		super(Category.class);
	}
}
