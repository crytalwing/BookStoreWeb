package soen.eighteen.Dao.Impl;

import soen.eighteen.Dao.AbstractDao;
import soen.eighteen.Entity.Publisher;

public class PublisherAbstractImpl  extends AbstractDao<Publisher>{
	public PublisherAbstractImpl()
	{
		super(Publisher.class);
	}


}
