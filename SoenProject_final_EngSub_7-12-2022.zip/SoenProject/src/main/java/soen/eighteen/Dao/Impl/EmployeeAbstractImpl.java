package soen.eighteen.Dao.Impl;

import soen.eighteen.Dao.AbstractDao;
import soen.eighteen.Entity.CategoryDetail;
import soen.eighteen.Entity.Employee;

public class EmployeeAbstractImpl extends AbstractDao<Employee>{
	public EmployeeAbstractImpl() {
		super(Employee.class);
	}

}
