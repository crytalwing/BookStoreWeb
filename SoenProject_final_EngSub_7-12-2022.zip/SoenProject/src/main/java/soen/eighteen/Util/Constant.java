package soen.eighteen.Util;

public class Constant {
	public static final String DIR = "/Users/vinguyen/eclipse-workspace/SoenProject/src/main/webapp/WEB-INF/upload/";

}
